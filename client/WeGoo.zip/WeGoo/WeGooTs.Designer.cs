﻿using System;
using System.Windows.Forms;

namespace WeGoo
{
    partial class WeGooTs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            //MessageBox.Show("关闭程序");
            _wechatsdk.ExitAllSubThread();
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ListViewItem listViewItem8 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem9 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem10 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem11 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem12 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem13 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem14 = new System.Windows.Forms.ListViewItem("");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WeGooTs));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tslblWeChatId = new System.Windows.Forms.ToolStripStatusLabel();
            this.tslblWeChatBaseAddress = new System.Windows.Forms.ToolStripStatusLabel();
            this.tslblInjectName = new System.Windows.Forms.ToolStripStatusLabel();
            this.tslblInjectAddress = new System.Windows.Forms.ToolStripStatusLabel();
            this.tslblWebSocket = new System.Windows.Forms.ToolStripStatusLabel();
            this.tslblwechatversion = new System.Windows.Forms.ToolStripStatusLabel();
            this.txtwxid = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lvwChatroom = new System.Windows.Forms.ListView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pbxSetting = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.txtrecmsg = new System.Windows.Forms.TextBox();
            this.livMessageList = new System.Windows.Forms.ListView();
            this.chId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clSrvid = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chWxid = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chSender = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clContent = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clTime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel3 = new System.Windows.Forms.Panel();
            this.cbxask = new System.Windows.Forms.CheckBox();
            this.txtsendmessage = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txttimes = new System.Windows.Forms.TextBox();
            this.txtmsg = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.statusStrip1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSetting)).BeginInit();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tslblWeChatId,
            this.tslblWeChatBaseAddress,
            this.tslblInjectName,
            this.tslblInjectAddress,
            this.tslblWebSocket,
            this.tslblwechatversion});
            this.statusStrip1.Location = new System.Drawing.Point(0, 539);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(949, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            this.statusStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.statusStrip1_ItemClicked);
            // 
            // tslblWeChatId
            // 
            this.tslblWeChatId.Name = "tslblWeChatId";
            this.tslblWeChatId.Size = new System.Drawing.Size(89, 17);
            this.tslblWeChatId.Text = "tslblWeChatId";
            // 
            // tslblWeChatBaseAddress
            // 
            this.tslblWeChatBaseAddress.Name = "tslblWeChatBaseAddress";
            this.tslblWeChatBaseAddress.Size = new System.Drawing.Size(153, 17);
            this.tslblWeChatBaseAddress.Text = "tslblWeChatBaseAddress";
            // 
            // tslblInjectName
            // 
            this.tslblInjectName.Name = "tslblInjectName";
            this.tslblInjectName.Size = new System.Drawing.Size(98, 17);
            this.tslblInjectName.Text = "tslblInjectName";
            // 
            // tslblInjectAddress
            // 
            this.tslblInjectAddress.Name = "tslblInjectAddress";
            this.tslblInjectAddress.Size = new System.Drawing.Size(111, 17);
            this.tslblInjectAddress.Text = "tslblInjectAddress";
            // 
            // tslblWebSocket
            // 
            this.tslblWebSocket.Name = "tslblWebSocket";
            this.tslblWebSocket.Size = new System.Drawing.Size(78, 17);
            this.tslblWebSocket.Text = "tsWebSoket";
            // 
            // tslblwechatversion
            // 
            this.tslblwechatversion.Name = "tslblwechatversion";
            this.tslblwechatversion.Size = new System.Drawing.Size(97, 17);
            this.tslblwechatversion.Text = "WeChatVersion";
            // 
            // txtwxid
            // 
            this.txtwxid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtwxid.Location = new System.Drawing.Point(57, 10);
            this.txtwxid.Name = "txtwxid";
            this.txtwxid.Size = new System.Drawing.Size(134, 14);
            this.txtwxid.TabIndex = 4;
            this.txtwxid.Text = "wxid or chatroom";
            // 
            // btnSend
            // 
            this.btnSend.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSend.Location = new System.Drawing.Point(542, 109);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 5;
            this.btnSend.Text = "btnSend";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 320F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 1, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(949, 539);
            this.tableLayoutPanel1.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.tableLayoutPanel1.SetRowSpan(this.panel1, 2);
            this.panel1.Size = new System.Drawing.Size(320, 539);
            this.panel1.TabIndex = 9;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.panel4, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel5, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(320, 539);
            this.tableLayoutPanel2.TabIndex = 10;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(80, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(10);
            this.panel4.Size = new System.Drawing.Size(240, 539);
            this.panel4.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel7.Location = new System.Drawing.Point(10, 405);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(220, 124);
            this.panel7.TabIndex = 11;
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.AutoScroll = true;
            this.panel6.Controls.Add(this.lvwChatroom);
            this.panel6.Location = new System.Drawing.Point(10, 10);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(220, 386);
            this.panel6.TabIndex = 10;
            // 
            // lvwChatroom
            // 
            this.lvwChatroom.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.lvwChatroom.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lvwChatroom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvwChatroom.Font = new System.Drawing.Font("微软雅黑 Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lvwChatroom.FullRowSelect = true;
            this.lvwChatroom.HideSelection = false;
            this.lvwChatroom.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem8,
            listViewItem9,
            listViewItem10,
            listViewItem11,
            listViewItem12,
            listViewItem13,
            listViewItem14});
            this.lvwChatroom.LargeImageList = this.imageList1;
            this.lvwChatroom.Location = new System.Drawing.Point(0, 0);
            this.lvwChatroom.Name = "lvwChatroom";
            this.lvwChatroom.Size = new System.Drawing.Size(220, 386);
            this.lvwChatroom.SmallImageList = this.imageList1;
            this.lvwChatroom.TabIndex = 0;
            this.lvwChatroom.UseCompatibleStateImageBehavior = false;
            this.lvwChatroom.View = System.Windows.Forms.View.Details;
            this.lvwChatroom.SelectedIndexChanged += new System.EventHandler(this.lvwChatroom_SelectedIndexChanged);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "user.png");
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.Controls.Add(this.pictureBox2);
            this.panel5.Controls.Add(this.pictureBox1);
            this.panel5.Controls.Add(this.pbxSetting);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Margin = new System.Windows.Forms.Padding(0);
            this.panel5.Name = "panel5";
            this.panel5.Padding = new System.Windows.Forms.Padding(3);
            this.panel5.Size = new System.Drawing.Size(80, 539);
            this.panel5.TabIndex = 1;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.Image = global::WeGoo.Properties.Resources.chatroom;
            this.pictureBox2.Location = new System.Drawing.Point(20, 125);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(40, 40);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(20, 63);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 40);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pbxSetting
            // 
            this.pbxSetting.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pbxSetting.Image = ((System.Drawing.Image)(resources.GetObject("pbxSetting.Image")));
            this.pbxSetting.InitialImage = null;
            this.pbxSetting.Location = new System.Drawing.Point(23, 489);
            this.pbxSetting.Name = "pbxSetting";
            this.pbxSetting.Size = new System.Drawing.Size(30, 30);
            this.pbxSetting.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxSetting.TabIndex = 0;
            this.pbxSetting.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.tableLayoutPanel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(320, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(20, 20, 0, 0);
            this.panel2.Size = new System.Drawing.Size(629, 404);
            this.panel2.TabIndex = 10;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.txtrecmsg, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.livMessageList, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(20, 20);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(609, 384);
            this.tableLayoutPanel3.TabIndex = 13;
            // 
            // txtrecmsg
            // 
            this.txtrecmsg.BackColor = System.Drawing.SystemColors.Control;
            this.txtrecmsg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtrecmsg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtrecmsg.Font = new System.Drawing.Font("微软雅黑 Light", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtrecmsg.Location = new System.Drawing.Point(0, 192);
            this.txtrecmsg.Margin = new System.Windows.Forms.Padding(0);
            this.txtrecmsg.Multiline = true;
            this.txtrecmsg.Name = "txtrecmsg";
            this.txtrecmsg.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtrecmsg.Size = new System.Drawing.Size(609, 192);
            this.txtrecmsg.TabIndex = 13;
            // 
            // livMessageList
            // 
            this.livMessageList.BackColor = System.Drawing.SystemColors.Control;
            this.livMessageList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.livMessageList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chId,
            this.clType,
            this.clSrvid,
            this.chWxid,
            this.chSender,
            this.clContent,
            this.clTime});
            this.livMessageList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.livMessageList.Font = new System.Drawing.Font("微软雅黑 Light", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.livMessageList.GridLines = true;
            this.livMessageList.HideSelection = false;
            this.livMessageList.Location = new System.Drawing.Point(3, 3);
            this.livMessageList.Name = "livMessageList";
            this.livMessageList.Size = new System.Drawing.Size(603, 186);
            this.livMessageList.TabIndex = 14;
            this.livMessageList.UseCompatibleStateImageBehavior = false;
            this.livMessageList.View = System.Windows.Forms.View.Details;
            // 
            // chId
            // 
            this.chId.Text = "序号";
            this.chId.Width = 44;
            // 
            // clType
            // 
            this.clType.Text = "消息类型";
            this.clType.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.clType.Width = 78;
            // 
            // clSrvid
            // 
            this.clSrvid.Text = "消息分类";
            this.clSrvid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.clSrvid.Width = 70;
            // 
            // chWxid
            // 
            this.chWxid.Text = "来自于";
            this.chWxid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // chSender
            // 
            this.chSender.Text = "发送人";
            this.chSender.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.chSender.Width = 72;
            // 
            // clContent
            // 
            this.clContent.Text = "消息内容";
            this.clContent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.clContent.Width = 136;
            // 
            // clTime
            // 
            this.clTime.Text = "时间";
            this.clTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.clTime.Width = 83;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.cbxask);
            this.panel3.Controls.Add(this.txtsendmessage);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.txttimes);
            this.panel3.Controls.Add(this.txtwxid);
            this.panel3.Controls.Add(this.txtmsg);
            this.panel3.Controls.Add(this.btnSend);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(320, 404);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.panel3.Size = new System.Drawing.Size(629, 135);
            this.panel3.TabIndex = 11;
            // 
            // cbxask
            // 
            this.cbxask.AutoSize = true;
            this.cbxask.Location = new System.Drawing.Point(217, 9);
            this.cbxask.Name = "cbxask";
            this.cbxask.Size = new System.Drawing.Size(48, 16);
            this.cbxask.TabIndex = 11;
            this.cbxask.Text = "每隔";
            this.cbxask.UseVisualStyleBackColor = true;
            // 
            // txtsendmessage
            // 
            this.txtsendmessage.BackColor = System.Drawing.Color.PaleGreen;
            this.txtsendmessage.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtsendmessage.Location = new System.Drawing.Point(408, 10);
            this.txtsendmessage.Name = "txtsendmessage";
            this.txtsendmessage.Size = new System.Drawing.Size(219, 14);
            this.txtsendmessage.TabIndex = 10;
            this.txtsendmessage.Text = "在干嘛呢？商量好了吗？";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(319, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 12);
            this.label2.TabIndex = 9;
            this.label2.Text = "毫秒自动发送";
            // 
            // txttimes
            // 
            this.txttimes.BackColor = System.Drawing.SystemColors.HotTrack;
            this.txttimes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txttimes.Location = new System.Drawing.Point(271, 10);
            this.txttimes.Name = "txttimes";
            this.txttimes.Size = new System.Drawing.Size(36, 14);
            this.txttimes.TabIndex = 8;
            this.txttimes.Text = "2000";
            // 
            // txtmsg
            // 
            this.txtmsg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtmsg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtmsg.Location = new System.Drawing.Point(20, 30);
            this.txtmsg.Multiline = true;
            this.txtmsg.Name = "txtmsg";
            this.txtmsg.Size = new System.Drawing.Size(606, 73);
            this.txtmsg.TabIndex = 6;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 60000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 12);
            this.label1.TabIndex = 12;
            this.label1.Text = "发送到:";
            // 
            // WeGooTs
            // 
            this.AcceptButton = this.btnSend;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(949, 561);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.statusStrip1);
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "WeGooTs";
            this.Text = "WeGooTs";
            this.Load += new System.EventHandler(this.WeGooTs_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSetting)).EndInit();
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }



        #endregion
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tslblWeChatId;
        private System.Windows.Forms.ToolStripStatusLabel tslblInjectAddress;
        private System.Windows.Forms.ToolStripStatusLabel tslblWeChatBaseAddress;
        private System.Windows.Forms.ToolStripStatusLabel tslblInjectName;
        private System.Windows.Forms.ToolStripStatusLabel tslblWebSocket;
        private System.Windows.Forms.TextBox txtwxid;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtmsg;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pbxSetting;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ListView lvwChatroom;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private TableLayoutPanel tableLayoutPanel3;
        private TextBox txtrecmsg;
        private ListView livMessageList;
        private ColumnHeader chId;
        private ColumnHeader clType;
        private ColumnHeader chWxid;
        private ColumnHeader chSender;
        private ColumnHeader clContent;
        private ColumnHeader clTime;
        private ColumnHeader clSrvid;
        private CheckBox cbxask;
        private TextBox txtsendmessage;
        private Label label2;
        private TextBox txttimes;
        private Timer timer1;
        private ToolStripStatusLabel tslblwechatversion;
        private Label label1;
    }
}