﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.WebSockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;


namespace WeGoo
{
    public partial class WeGooTs : Form
    {
        WeChatSDK _wechatsdk=WeChatSDK.Instance;
        public WeGooTs()
        {
            InitializeComponent();
        }
 
        public void GetMessage() {
            while (true) {
                for (var i = 0; i < _wechatsdk.MessageTotal; i++) {
                    //txtrecmsg.AppendText(_wechatsdk.GetMessage);
                    //txtrecmsg.AppendText(Environment.NewLine);
                    //txtrecmsg.ScrollToCaret();
                    if (this.IsHandleCreated)
                    {
                        string _msg = _wechatsdk.GetMessage;
                        var _json = JObject.Parse(_msg);

                       // var _wixid = _json["sender"].ToString();
                        
                        txtrecmsg.BeginInvoke(new Action(() =>
                        {
                            this.txtrecmsg.AppendText(_msg);
                            this.txtrecmsg.AppendText(Environment.NewLine);
                            this.txtrecmsg.ScrollToCaret();

                        }));
                        JObject _baseMsg = JObject.Parse(_wechatsdk.GetBaseMessage);
                        //{"content":"服务端心跳包发送，按设置周期，一般间隔15秒！",
                        //"id":"","sender":"ROOT","srvid":1,"time":"2020-05-08 07:37:32","type":5005}
                        
                        livMessageList.BeginInvoke(new Action(() => {
                            ListViewItem _item = new ListViewItem();
                            string _type=null, _srvid=null, _sender=null, _wxid=null, _content=null,_time = null;
                            if (_baseMsg.ContainsKey("type"))  _type = _baseMsg["type"].ToString();
                            if (_baseMsg.ContainsKey("srvid")) _srvid = _baseMsg["srvid"].ToString();
                            if (_baseMsg.ContainsKey("sender")) _sender = _baseMsg["sender"].ToString();
                            if (_baseMsg.ContainsKey("wxid")) _wxid = _baseMsg["wxid"].ToString();
                            if (_baseMsg.ContainsKey("content")) _content = _baseMsg["content"].ToString();
                            if (_baseMsg.ContainsKey("time")) _time = _baseMsg["time"].ToString();
                            _item.Text=(livMessageList.Items.Count +1).ToString();
                            _item.SubItems.Add(_type);
                            _item.SubItems.Add(_srvid);
                            _item.SubItems.Add(_sender);
                            _item.SubItems.Add(_wxid);
                            _item.SubItems.Add(_content);
                            _item.SubItems.Add(_time);
                            livMessageList.Items.Add(_item);
                            livMessageList.Items[livMessageList.Items.Count - 1].EnsureVisible();
                        }));

                    }
                }
                Thread.Sleep(_wechatsdk.ReleaseCPU);
            }
        
        }

        public void GetWebSocketStatus() {
            while (true) {
                switch (_wechatsdk.GetWebSocketStatus)
                {
                    case WebSocketState.Open:
                        tslblWebSocket.Text = "与服务器连接正常";
                        break;
                    case WebSocketState.None:
                    case WebSocketState.Closed:
                        tslblWebSocket.Text = "与服务器连接断开";
                        break;
                    default:
                        tslblWebSocket.Text = "与服务器连接未知";
                        break;
                }
                    
                Thread.Sleep(5000);
            };
            
        }
        public void sendtowxid(object source, System.Timers.ElapsedEventArgs e) {
            Trace.WriteLine(String.Format("is running....")) ;
            _wechatsdk.SendTextMessage(txtwxid.Text,txtsendmessage.Text);
        }
        private void WeGooTs_Load(object sender, EventArgs e)
        {
            //Trace.WriteLine(_wechatsdk.GetInjectBaseAddress());
            
            tslblWeChatId.Text = String.Format("微信进程号:{0}",_wechatsdk.GetWeChatProcessId());
            tslblWeChatBaseAddress.Text = String.Format("微信入口点基址:0x{0}",_wechatsdk.FindModuleBaseAddress(_wechatsdk.GetWeChatProcess(),"wechatwin.dll").ToString("x8").ToUpper());
            tslblInjectAddress.Text = String.Format("注入模块基址:0x{0}",_wechatsdk.GetInjectBaseAddress().ToString("x8").ToUpper());
            tslblInjectName.Text = String.Format("注入模块名称：{0}",_wechatsdk.InjectDllName);
            tslblwechatversion.Text = String.Format("微信版本号:{0}",_wechatsdk.GetWeChatViersion());
            try 
            {
                //new Thread(new ParameterizedThreadStart(SetChatroomList)).Start((object) _wechatsdk.GetUserList);

                //new Thread(GetWebSocketStatus).Start();

                ThreadPool.QueueUserWorkItem(p=>{
                    SetChatroomList(_wechatsdk.GetUserList);
                    GetWebSocketStatus();
                    //GetMessage();
                });
                new Thread(GetMessage).Start();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnSend_Click(object sender, EventArgs e)
        {
            if (txtmsg.Text == "") return;
            _wechatsdk.SendTextMessage(txtwxid.Text,txtmsg.Text);
            txtmsg.Text = "";
            txtmsg.Focus();
            
        }


        public void SetChatroomList(Object _dic) {
            _dic = (Dictionary<string, string>)_dic;

            lvwChatroom.BeginInvoke(new Action(() => {
                lvwChatroom.Items.Clear();
                lvwChatroom.Columns.Clear();
                lvwChatroom.Columns.Add("WXID", 40);
                lvwChatroom.Columns.Add("昵称", -2);
                foreach (var _item in (Dictionary<string, string>)_dic)
                {
                    ListViewItem _list = new ListViewItem();
                    //_list.Tag = _item.Key;
                    _list.Text = _item.Key;
                    _list.SubItems.Add(_item.Value);
                    _list.SubItems.Add(_item.Key);
                    _list.ImageIndex = 0;
                    lvwChatroom.Items.Add(_list);
                }
            }));

        }
  



        private void pictureBox1_Click(object sender, EventArgs e)
        {
            new Thread(new ParameterizedThreadStart(SetChatroomList)).Start(_wechatsdk.GetUserList);
        }

        private void lvwChatroom_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtwxid.Text  = lvwChatroom.FocusedItem.SubItems[0].Text;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            new Thread(new ParameterizedThreadStart(SetChatroomList)).Start(_wechatsdk.GetChatRoom);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (cbxask.Checked)
            {
                _wechatsdk.SendTextMessage(txtwxid.Text , txtsendmessage.Text);
            }
        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void btnSendImage_Click(object sender, EventArgs e)
        {
        }

        private void btnSendAtMessage_Click(object sender, EventArgs e)
        {
        }

        private void btnGetChatroomUserList_Click(object sender, EventArgs e)
        {
            _wechatsdk.ChatroomUserList();
        }

        private void btnSendWeb_Click(object sender, EventArgs e)
        {
            RestClient _restClient = new RestClient();
            RestRequest _resetRequest = new RestRequest("http://www.baidu.com", Method.GET);
            var _rest = _restClient.Execute(_resetRequest);
            Trace.WriteLine(_rest.Content);
        }


    }
}
